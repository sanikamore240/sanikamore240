
import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { Product, CartItem, User, Order } from '../types';
import { api } from '../services/api';
import { db } from '../services/database';

interface AppContextType {
  products: Product[];
  cart: CartItem[];
  user: User | null;
  orders: Order[];
  loading: boolean;
  isCartOpen: boolean;
  setCartOpen: (open: boolean) => void;
  addToCart: (product: Product) => void;
  removeFromCart: (productId: string) => void;
  updateQuantity: (productId: string, quantity: number) => void;
  clearCart: () => void;
  login: (email: string) => Promise<void>;
  register: (details: { name: string, email: string, phone: string, address: string }) => Promise<void>;
  logout: () => void;
  placeOrder: () => Promise<void>;
  refreshOrders: () => Promise<void>;
  refreshProducts: () => Promise<void>;
  addNewProduct: (p: Omit<Product, 'id' | 'rating'>) => Promise<void>;
  removeProduct: (id: string) => Promise<void>;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [products, setProducts] = useState<Product[]>([]);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [user, setUser] = useState<User | null>(db.getSession());
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(false);
  const [isCartOpen, setIsCartOpen] = useState(false);

  const fetchProducts = useCallback(async () => {
    setLoading(true);
    const fetchedProducts = await api.fetchProducts();
    setProducts(fetchedProducts);
    setLoading(false);
  }, []);

  useEffect(() => {
    fetchProducts();
    const savedCart = localStorage.getItem('lumina_cart');
    if (savedCart) setCart(JSON.parse(savedCart));
  }, [fetchProducts]);

  useEffect(() => {
    if (user) {
      api.fetchUserOrders(user.id).then(setOrders);
    }
  }, [user]);

  useEffect(() => {
    localStorage.setItem('lumina_cart', JSON.stringify(cart));
  }, [cart]);

  const addToCart = useCallback((product: Product) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        return prev.map(item =>
          item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prev, { ...product, quantity: 1 }];
    });
    setIsCartOpen(true);
  }, []);

  const removeFromCart = useCallback((productId: string) => {
    setCart(prev => prev.filter(item => item.id !== productId));
  }, []);

  const updateQuantity = useCallback((productId: string, quantity: number) => {
    if (quantity <= 0) {
      removeFromCart(productId);
      return;
    }
    setCart(prev =>
      prev.map(item => (item.id === productId ? { ...item, quantity } : item))
    );
  }, [removeFromCart]);

  const clearCart = useCallback(() => setCart([]), []);

  const login = async (email: string) => {
    const loggedInUser = await api.login(email);
    setUser(loggedInUser);
  };

  const register = async (details: { name: string, email: string, phone: string, address: string }) => {
    const newUser = await api.register(details);
    setUser(newUser);
  };

  const logout = () => {
    api.logout();
    setUser(null);
    setOrders([]);
  };

  const placeOrder = async () => {
    if (!user || cart.length === 0) return;
    const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0) + 10;
    const newOrder = await api.createOrder(user.id, cart, total);
    setOrders(prev => [newOrder, ...prev]);
    clearCart();
    setIsCartOpen(false);
  };

  const refreshOrders = async () => {
    if (!user) return;
    const userOrders = await api.fetchUserOrders(user.id);
    setOrders(userOrders);
  };

  const refreshProducts = async () => {
    await fetchProducts();
  };

  const addNewProduct = async (p: Omit<Product, 'id' | 'rating'>) => {
    await api.addProduct(p);
    await fetchProducts();
  };

  const removeProduct = async (id: string) => {
    await api.deleteProduct(id);
    await fetchProducts();
  };

  return (
    <AppContext.Provider value={{
      products, cart, user, orders, loading, isCartOpen,
      setCartOpen: setIsCartOpen,
      addToCart, removeFromCart, updateQuantity, clearCart,
      login, register, logout, placeOrder, refreshOrders,
      refreshProducts, addNewProduct, removeProduct
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within AppProvider');
  return context;
};
