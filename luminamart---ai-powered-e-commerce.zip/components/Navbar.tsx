
import React, { useState } from 'react';
import { useApp } from '../context/AppContext';

const Navbar: React.FC = () => {
  const { cart, user, logout, setCartOpen } = useApp();
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const cartCount = cart.reduce((sum, item) => sum + item.quantity, 0);

  return (
    <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-md border-b border-gray-100 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          <div className="flex items-center">
            <a href="#/" className="text-2xl font-bold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
              LuminaMart
            </a>
            <div className="hidden md:ml-10 md:flex space-x-8">
              <a href="#/products" className="text-gray-600 hover:text-indigo-600 transition-colors font-medium">Products</a>
              <a href="#/admin" className="text-gray-400 hover:text-indigo-600 transition-colors font-medium text-xs flex items-center">
                <svg className="h-3 w-3 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4" />
                </svg>
                Admin Panel
              </a>
            </div>
          </div>
          
          <div className="flex items-center space-x-2 sm:space-x-4">
            <button 
              onClick={() => setCartOpen(true)}
              className="relative p-2 text-gray-500 hover:text-indigo-600 transition-all group"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 transition-transform group-hover:scale-110" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
              </svg>
              {cartCount > 0 && (
                <span className="absolute top-0 right-0 inline-flex items-center justify-center px-1.5 py-0.5 text-[10px] font-bold leading-none text-white transform translate-x-1/2 -translate-y-1/2 bg-indigo-600 rounded-full border-2 border-white">
                  {cartCount}
                </span>
              )}
            </button>

            {user ? (
              <div className="relative">
                <button 
                  onClick={() => setIsMenuOpen(!isMenuOpen)}
                  className="flex items-center space-x-2 p-1 pl-3 rounded-full hover:bg-gray-50 transition-all border border-transparent hover:border-gray-100"
                >
                  <span className="text-sm font-semibold text-gray-700 hidden sm:block">{user.name}</span>
                  <div className="w-8 h-8 bg-indigo-100 text-indigo-600 rounded-full flex items-center justify-center text-xs font-bold">
                    {user.name.charAt(0)}
                  </div>
                </button>

                {isMenuOpen && (
                  <>
                    <div className="fixed inset-0 z-10" onClick={() => setIsMenuOpen(false)}></div>
                    <div className="absolute right-0 mt-2 w-48 bg-white rounded-2xl shadow-xl border border-gray-100 py-2 z-20 animate-slide-down">
                      <a href="#/profile" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 font-medium">Profile & Orders</a>
                      <a href="#/admin" className="block px-4 py-2 text-sm text-gray-700 hover:bg-gray-50 font-medium md:hidden">Admin Panel</a>
                      <hr className="my-2 border-gray-50" />
                      <button 
                        onClick={() => {
                          logout();
                          setIsMenuOpen(false);
                        }}
                        className="w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-red-50 font-medium"
                      >
                        Logout
                      </button>
                    </div>
                  </>
                )}
              </div>
            ) : (
              <a href="#/auth" className="bg-gray-900 text-white px-5 py-2 rounded-full text-sm font-bold hover:bg-gray-800 transition-all">
                Sign In
              </a>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
