
import React from 'react';
import { useApp } from '../context/AppContext';

const CartDrawer: React.FC = () => {
  const { cart, isCartOpen, setCartOpen, removeFromCart, updateQuantity, products } = useApp();
  const subtotal = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

  if (!isCartOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] overflow-hidden">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-gray-900/60 backdrop-blur-sm transition-opacity animate-fade-in"
        onClick={() => setCartOpen(false)}
      ></div>

      {/* Drawer */}
      <div className="absolute inset-y-0 right-0 max-w-full flex">
        <div className="w-screen max-w-md bg-white shadow-2xl flex flex-col animate-slide-left">
          {/* Header */}
          <div className="px-6 py-6 border-b border-gray-100 flex items-center justify-between">
            <h2 className="text-2xl font-bold text-gray-900 tracking-tight">Your Cart</h2>
            <button 
              onClick={() => setCartOpen(false)}
              className="p-2 text-gray-400 hover:text-gray-900 hover:bg-gray-50 rounded-full transition-all"
            >
              <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>

          {/* Content */}
          <div className="flex-1 overflow-y-auto px-6 py-4 scrollbar-hide">
            {cart.length === 0 ? (
              <div className="h-full flex flex-col items-center justify-center text-center space-y-6">
                <div className="w-24 h-24 bg-indigo-50 text-indigo-200 rounded-full flex items-center justify-center">
                   <svg className="h-12 w-12" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
                   </svg>
                </div>
                <div>
                  <h3 className="text-xl font-bold text-gray-900">Your cart is empty</h3>
                  <p className="text-gray-500 mt-2">Looks like you haven't added anything yet.</p>
                </div>
                
                {/* Suggestions inside drawer */}
                <div className="w-full pt-10">
                   <p className="text-xs font-bold text-gray-400 uppercase tracking-widest mb-6">Popular items</p>
                   <div className="space-y-4">
                      {products.slice(0, 3).map(p => (
                        <div key={p.id} className="flex items-center space-x-4 p-3 rounded-2xl hover:bg-gray-50 transition-colors border border-transparent hover:border-gray-100 group">
                           <img src={p.image} className="w-16 h-16 rounded-xl object-cover" alt="" />
                           <div className="flex-1 text-left">
                              <p className="font-bold text-gray-900 text-sm">{p.name}</p>
                              <p className="text-indigo-600 font-bold text-sm">${p.price}</p>
                           </div>
                           <button 
                             onClick={() => useApp().addToCart(p)}
                             className="p-2 bg-white border border-gray-100 rounded-lg shadow-sm opacity-0 group-hover:opacity-100 transition-opacity hover:bg-indigo-600 hover:text-white"
                           >
                             <svg className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                             </svg>
                           </button>
                        </div>
                      ))}
                   </div>
                </div>
              </div>
            ) : (
              <div className="space-y-6">
                {cart.map(item => (
                  <div key={item.id} className="flex items-center space-x-4">
                    <div className="w-20 h-20 bg-gray-50 rounded-2xl overflow-hidden border border-gray-100 flex-shrink-0">
                      <img src={item.image} alt="" className="w-full h-full object-cover" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-bold text-gray-900 truncate">{item.name}</p>
                      <p className="text-sm text-gray-500 mb-2">${item.price}</p>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center bg-gray-50 rounded-lg p-1">
                          <button 
                            onClick={() => updateQuantity(item.id, item.quantity - 1)}
                            className="p-1 text-gray-400 hover:text-gray-900"
                          >
                            <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M20 12H4" />
                            </svg>
                          </button>
                          <span className="w-8 text-center text-sm font-bold">{item.quantity}</span>
                          <button 
                            onClick={() => updateQuantity(item.id, item.quantity + 1)}
                            className="p-1 text-gray-400 hover:text-gray-900"
                          >
                            <svg className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                            </svg>
                          </button>
                        </div>
                        <button 
                          onClick={() => removeFromCart(item.id)}
                          className="text-xs font-bold text-red-400 hover:text-red-600 uppercase"
                        >
                          Remove
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Footer */}
          {cart.length > 0 && (
            <div className="p-6 border-t border-gray-100 bg-gray-50/50 space-y-4">
              <div className="flex items-center justify-between text-gray-500">
                <span className="font-medium">Subtotal</span>
                <span className="font-bold text-gray-900 text-xl tracking-tight">${subtotal.toLocaleString(undefined, { minimumFractionDigits: 2 })}</span>
              </div>
              <p className="text-xs text-gray-400">Shipping and taxes are calculated at checkout.</p>
              <div className="grid grid-cols-1 gap-3">
                <a 
                  href="#/checkout" 
                  onClick={() => setCartOpen(false)}
                  className="w-full bg-indigo-600 text-white py-4 rounded-2xl font-bold text-center shadow-lg shadow-indigo-200 hover:bg-indigo-700 transition-all active:scale-95"
                >
                  Checkout Now
                </a>
                <button 
                  onClick={() => setCartOpen(false)}
                  className="w-full bg-white text-gray-600 py-4 rounded-2xl font-bold border border-gray-200 hover:bg-gray-50 transition-all"
                >
                  Continue Shopping
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default CartDrawer;
