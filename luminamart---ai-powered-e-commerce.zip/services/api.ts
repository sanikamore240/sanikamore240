
import { db } from './database';
import { Product, User, Order, CartItem } from '../types';

const LATENCY = 600;

const sleep = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

export const api = {
  // Auth
  login: async (email: string): Promise<User> => {
    await sleep(LATENCY);
    const user = db.findUserByEmail(email);
    if (!user) throw new Error('User not found. Please register first.');
    db.setSession(user);
    return user;
  },

  register: async (details: { name: string, email: string, phone: string, address: string }): Promise<User> => {
    await sleep(LATENCY);
    if (db.findUserByEmail(details.email)) throw new Error('An account with this email already exists.');
    
    const newUser: User = {
      id: Math.random().toString(36).substr(2, 9),
      name: details.name,
      email: details.email,
      phone: details.phone,
      address: details.address,
      role: 'user'
    };
    
    db.addUser(newUser);
    db.setSession(newUser);
    return newUser;
  },

  logout: async () => {
    await sleep(200);
    db.setSession(null);
  },

  // Products
  fetchProducts: async (): Promise<Product[]> => {
    await sleep(LATENCY);
    return db.getProducts();
  },

  addProduct: async (productData: Omit<Product, 'id' | 'rating'>): Promise<Product> => {
    await sleep(LATENCY);
    const newProduct: Product = {
      ...productData,
      id: Math.random().toString(36).substr(2, 9),
      rating: 5.0
    };
    db.saveProduct(newProduct);
    return newProduct;
  },

  deleteProduct: async (id: string): Promise<void> => {
    await sleep(LATENCY);
    db.deleteProduct(id);
  },

  // Orders
  fetchUserOrders: async (userId: string): Promise<Order[]> => {
    await sleep(LATENCY);
    return db.getOrders(userId);
  },

  createOrder: async (userId: string, items: CartItem[], total: number): Promise<Order> => {
    await sleep(LATENCY + 400);
    const newOrder: Order = {
      id: `ORD-${Math.random().toString(36).substr(2, 9).toUpperCase()}`,
      userId,
      items: [...items],
      total,
      status: 'pending',
      createdAt: new Date().toISOString()
    };
    db.addOrder(newOrder);
    return newOrder;
  }
};
