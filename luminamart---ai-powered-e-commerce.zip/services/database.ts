
import { Product, User, Order } from '../types';
import { INITIAL_PRODUCTS } from '../constants';

const DB_KEYS = {
  PRODUCTS: 'lumina_db_products',
  USERS: 'lumina_db_users',
  ORDERS: 'lumina_db_orders',
  SESSION: 'lumina_db_session'
};

export const db = {
  // Products
  getProducts: (): Product[] => {
    const data = localStorage.getItem(DB_KEYS.PRODUCTS);
    if (!data || JSON.parse(data).length === 0) {
      localStorage.setItem(DB_KEYS.PRODUCTS, JSON.stringify(INITIAL_PRODUCTS));
      return INITIAL_PRODUCTS;
    }
    return JSON.parse(data);
  },

  saveProduct: (product: Product) => {
    const products = db.getProducts();
    const index = products.findIndex(p => p.id === product.id);
    if (index > -1) {
      products[index] = product;
    } else {
      products.push(product);
    }
    localStorage.setItem(DB_KEYS.PRODUCTS, JSON.stringify(products));
    return products;
  },

  deleteProduct: (id: string) => {
    const products = db.getProducts().filter(p => p.id !== id);
    localStorage.setItem(DB_KEYS.PRODUCTS, JSON.stringify(products));
    return products;
  },

  // Users
  getUsers: (): User[] => {
    const data = localStorage.getItem(DB_KEYS.USERS);
    return data ? JSON.parse(data) : [];
  },

  addUser: (user: User) => {
    const users = db.getUsers();
    users.push(user);
    localStorage.setItem(DB_KEYS.USERS, JSON.stringify(users));
  },

  findUserByEmail: (email: string) => {
    return db.getUsers().find(u => u.email.toLowerCase() === email.toLowerCase());
  },

  // Orders
  getOrders: (userId?: string): Order[] => {
    const data = localStorage.getItem(DB_KEYS.ORDERS);
    const allOrders: Order[] = data ? JSON.parse(data) : [];
    if (userId) {
      return allOrders.filter(o => o.userId === userId);
    }
    return allOrders;
  },

  addOrder: (order: Order) => {
    const orders = db.getOrders();
    orders.push(order);
    localStorage.setItem(DB_KEYS.ORDERS, JSON.stringify(orders));
  },

  // Session
  setSession: (user: User | null) => {
    if (user) {
      localStorage.setItem(DB_KEYS.SESSION, JSON.stringify(user));
    } else {
      localStorage.removeItem(DB_KEYS.SESSION);
    }
  },

  getSession: (): User | null => {
    const data = localStorage.getItem(DB_KEYS.SESSION);
    return data ? JSON.parse(data) : null;
  }
};
