
import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getSmartProductSuggestions = async (query: string, availableProducts: string[]) => {
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `The user is looking for: "${query}". Based on our inventory list: [${availableProducts.join(", ")}], suggest the top 3 most relevant products and explain why briefly.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              productName: { type: Type.STRING },
              reason: { type: Type.STRING }
            },
            required: ["productName", "reason"]
          }
        }
      }
    });
    return JSON.parse(response.text);
  } catch (error) {
    console.error("Gemini Error:", error);
    return [];
  }
};

export const generateProductDescription = async (productName: string) => {
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Write a compelling, high-converting e-commerce product description for a product named "${productName}". Keep it under 100 words.`,
  });
  return response.text;
};
