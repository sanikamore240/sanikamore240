
import React, { useEffect, useState } from 'react';
import { useApp } from '../context/AppContext';
import { generateProductDescription } from '../services/geminiService';

const ProductDetail: React.FC<{ productId: string }> = ({ productId }) => {
  const { products, addToCart } = useApp();
  const product = products.find(p => p.id === productId);
  const [aiDescription, setAiDescription] = useState<string | null>(null);
  const [loadingAi, setLoadingAi] = useState(false);

  useEffect(() => {
    if (product) {
      window.scrollTo(0, 0);
    }
  }, [product]);

  const handleAiDescription = async () => {
    if (!product) return;
    setLoadingAi(true);
    const desc = await generateProductDescription(product.name);
    setAiDescription(desc);
    setLoadingAi(false);
  };

  if (!product) return <div className="p-20 text-center">Product not found.</div>;

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
        {/* Image */}
        <div className="bg-white rounded-3xl overflow-hidden shadow-lg border border-gray-100">
          <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
        </div>

        {/* Content */}
        <div className="flex flex-col">
          <nav className="text-sm text-gray-400 mb-4">
            <a href="#/" className="hover:text-indigo-600">Home</a> / 
            <a href="#/products" className="hover:text-indigo-600 mx-2">Products</a> / 
            <span className="text-gray-600 ml-2">{product.name}</span>
          </nav>
          
          <h1 className="text-4xl font-bold text-gray-900 mb-2">{product.name}</h1>
          <div className="flex items-center space-x-4 mb-6">
            <span className="text-3xl font-extrabold text-indigo-600">${product.price}</span>
            <span className="px-3 py-1 bg-green-100 text-green-700 text-xs font-bold rounded-full uppercase tracking-wider">In Stock</span>
          </div>

          <div className="prose prose-sm text-gray-600 mb-8">
            <p className="text-lg leading-relaxed">{product.description}</p>
          </div>

          {/* AI Description Feature */}
          <div className="mb-8 p-6 bg-purple-50 rounded-2xl border border-purple-100">
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-bold text-purple-700 uppercase flex items-center">
                <svg className="h-4 w-4 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a2 2 0 00-1.96 1.414l-.547 2.188a2 2 0 00.75 2.226l1.72 1.147a2 2 0 002.504-.25l1.414-1.414a2 2 0 00.078-2.693l-1.147-1.147z" />
                </svg>
                AI Insights
              </span>
              <button 
                onClick={handleAiDescription}
                disabled={loadingAi}
                className="text-sm text-purple-600 font-semibold hover:text-purple-800 transition-colors disabled:opacity-50"
              >
                {loadingAi ? 'Drafting...' : 'Enhance Description'}
              </button>
            </div>
            {aiDescription && (
              <p className="text-gray-700 italic animate-fade-in">{aiDescription}</p>
            )}
            {!aiDescription && !loadingAi && (
              <p className="text-gray-400 text-sm">Want to know more? Let LuminaAI create a professional review of this item for you.</p>
            )}
          </div>

          <div className="mt-auto space-y-4">
            <button 
              onClick={() => addToCart(product)}
              className="w-full bg-gray-900 text-white py-4 px-8 rounded-xl font-bold text-lg hover:bg-gray-800 transition-all flex items-center justify-center space-x-2"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
              </svg>
              <span>Add to Cart</span>
            </button>
            <div className="grid grid-cols-2 gap-4">
              <div className="flex items-center p-3 bg-gray-50 rounded-lg">
                <svg className="h-5 w-5 text-gray-400 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 10h18M7 15h1m4 0h1m-7 4h12a3 3 0 003-3V8a3 3 0 00-3-3H6a3 3 0 00-3 3v8a3 3 0 003 3z" />
                </svg>
                <span className="text-xs text-gray-500 font-medium">Secure Payment</span>
              </div>
              <div className="flex items-center p-3 bg-gray-50 rounded-lg">
                <svg className="h-5 w-5 text-gray-400 mr-2" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                <span className="text-xs text-gray-500 font-medium">Free Delivery</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductDetail;
