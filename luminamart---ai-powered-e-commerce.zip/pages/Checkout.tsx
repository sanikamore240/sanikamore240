
import React, { useState } from 'react';
import { useApp } from '../context/AppContext';

const Checkout: React.FC = () => {
  const { cart, user, placeOrder } = useApp();
  const [step, setStep] = useState(1);
  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0) + 10;

  if (step === 3) {
    return (
      <div className="max-w-2xl mx-auto px-4 py-24 text-center">
        <div className="bg-white p-12 rounded-3xl shadow-xl border border-green-50 animate-bounce-short">
          <div className="w-20 h-20 bg-green-100 text-green-600 rounded-full flex items-center justify-center mx-auto mb-8">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
            </svg>
          </div>
          <h2 className="text-4xl font-extrabold text-gray-900 mb-4">Order Placed!</h2>
          <p className="text-gray-500 text-lg mb-8">Thank you for shopping with LuminaMart. Your order is being processed and will be shipped soon.</p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <a href="#/" className="bg-indigo-600 text-white px-8 py-3 rounded-xl font-bold hover:bg-indigo-700">Back to Home</a>
            <button className="text-indigo-600 font-bold px-8 py-3 rounded-xl border border-indigo-100 hover:bg-indigo-50">View Order History</button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-12">
      <div className="flex justify-center mb-12">
        <div className="flex items-center space-x-4">
          <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold ${step >= 1 ? 'bg-indigo-600 text-white' : 'bg-gray-200 text-gray-500'}`}>1</div>
          <div className={`h-1 w-12 rounded-full ${step >= 2 ? 'bg-indigo-600' : 'bg-gray-200'}`}></div>
          <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold ${step >= 2 ? 'bg-indigo-600 text-white' : 'bg-gray-200 text-gray-500'}`}>2</div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        {/* Form */}
        <div className="space-y-8">
          {step === 1 ? (
            <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100">
              <h2 className="text-2xl font-bold mb-6">Shipping Details</h2>
              <form className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <input type="text" placeholder="First Name" className="p-4 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none" required />
                <input type="text" placeholder="Last Name" className="p-4 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none" required />
                <input type="email" placeholder="Email" defaultValue={user?.email} className="p-4 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none sm:col-span-2" required />
                <input type="text" placeholder="Address" className="p-4 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none sm:col-span-2" required />
                <input type="text" placeholder="City" className="p-4 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none" required />
                <input type="text" placeholder="ZIP Code" className="p-4 border border-gray-200 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none" required />
                <button 
                  type="button"
                  onClick={() => setStep(2)}
                  className="bg-indigo-600 text-white py-4 rounded-xl font-bold sm:col-span-2 mt-4 hover:bg-indigo-700"
                >
                  Continue to Payment
                </button>
              </form>
            </div>
          ) : (
            <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100">
              <h2 className="text-2xl font-bold mb-6">Payment Method</h2>
              <div className="space-y-4">
                <label className="flex items-center p-4 border-2 border-indigo-600 rounded-xl cursor-pointer bg-indigo-50">
                  <input type="radio" name="payment" defaultChecked className="text-indigo-600 h-5 w-5" />
                  <div className="ml-4">
                    <span className="block font-bold">Credit / Debit Card</span>
                    <span className="text-xs text-indigo-700">All major cards supported</span>
                  </div>
                </label>
                <div className="space-y-4 mt-6">
                  <input type="text" placeholder="Card Number" className="w-full p-4 border border-gray-200 rounded-xl outline-none" />
                  <div className="grid grid-cols-2 gap-4">
                    <input type="text" placeholder="MM/YY" className="p-4 border border-gray-200 rounded-xl outline-none" />
                    <input type="text" placeholder="CVC" className="p-4 border border-gray-200 rounded-xl outline-none" />
                  </div>
                </div>
                <button 
                  type="button"
                  onClick={() => {
                    placeOrder();
                    setStep(3);
                  }}
                  className="w-full bg-indigo-600 text-white py-4 rounded-xl font-bold mt-8 hover:bg-indigo-700"
                >
                  Pay ${total.toFixed(2)}
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Order Summary Summary */}
        <div>
          <div className="bg-white p-8 rounded-2xl shadow-sm border border-gray-100">
            <h2 className="text-xl font-bold mb-6">Items</h2>
            <div className="space-y-4 mb-6 max-h-96 overflow-y-auto pr-2">
              {cart.map(item => (
                <div key={item.id} className="flex items-center space-x-4">
                  <div className="w-16 h-16 bg-gray-50 rounded-lg overflow-hidden border">
                    <img src={item.image} alt={item.name} className="w-full h-full object-cover" />
                  </div>
                  <div className="flex-1">
                    <p className="font-semibold text-gray-900 line-clamp-1">{item.name}</p>
                    <p className="text-xs text-gray-400">Qty: {item.quantity}</p>
                  </div>
                  <span className="font-bold">${(item.price * item.quantity).toFixed(2)}</span>
                </div>
              ))}
            </div>
            <div className="border-t border-gray-100 pt-6 space-y-2">
              <div className="flex justify-between text-gray-600">
                <span>Shipping</span>
                <span>$10.00</span>
              </div>
              <div className="flex justify-between text-xl font-extrabold text-gray-900 pt-2">
                <span>Total</span>
                <span>${total.toFixed(2)}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Checkout;
