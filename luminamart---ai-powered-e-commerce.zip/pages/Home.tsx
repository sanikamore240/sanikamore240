
import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { getSmartProductSuggestions } from '../services/geminiService';

const Home: React.FC = () => {
  const { products, addToCart } = useApp();
  const [aiQuery, setAiQuery] = useState('');
  const [aiLoading, setAiLoading] = useState(false);
  const [suggestions, setSuggestions] = useState<{ productName: string, reason: string }[]>([]);

  const handleAiSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!aiQuery.trim()) return;
    setAiLoading(true);
    const productNames = products.map(p => p.name);
    const results = await getSmartProductSuggestions(aiQuery, productNames);
    setSuggestions(results);
    setAiLoading(false);
  };

  return (
    <div className="space-y-16 pb-20">
      {/* Hero Section */}
      <section className="relative bg-indigo-900 h-[600px] flex items-center overflow-hidden">
        <div className="absolute inset-0 opacity-40">
          <img 
            src="https://images.unsplash.com/photo-1441986300917-64674bd600d8?auto=format&fit=crop&w=1600&q=80" 
            className="w-full h-full object-cover"
            alt="Hero Background"
          />
        </div>
        <div className="absolute inset-0 bg-gradient-to-r from-indigo-950/80 to-transparent"></div>
        <div className="relative max-w-7xl mx-auto px-4 text-white text-center sm:text-left w-full">
          <div className="max-w-3xl">
            <span className="inline-block px-4 py-1 bg-indigo-500/30 backdrop-blur-md rounded-full text-sm font-bold tracking-widest uppercase mb-6 border border-indigo-400/20">
              Welcome to the future of retail
            </span>
            <h1 className="text-6xl md:text-8xl font-extrabold mb-8 leading-tight tracking-tighter">
              Evolve Your <br /><span className="bg-gradient-to-r from-indigo-300 to-purple-300 bg-clip-text text-transparent">Shopping Experience</span>
            </h1>
            <p className="text-xl md:text-2xl text-gray-300 mb-10 leading-relaxed max-w-2xl">
              Discover premium products curated with the power of Gemini AI. Quality, speed, and elegance in every click.
            </p>
            <div className="flex flex-col sm:flex-row gap-4">
              <a href="#/products" className="inline-block bg-white text-indigo-900 font-extrabold py-5 px-10 rounded-2xl transition-all hover:bg-indigo-50 hover:scale-105 shadow-xl shadow-indigo-950/20">
                Shop the Collection
              </a>
              <a href="#/about" className="inline-block bg-indigo-800/40 backdrop-blur-md border border-indigo-400/30 text-white font-bold py-5 px-10 rounded-2xl transition-all hover:bg-indigo-700/50">
                Learn More
              </a>
            </div>
          </div>
        </div>
      </section>

      {/* AI Assistant Section */}
      <section className="max-w-5xl mx-auto px-4 -mt-20 relative z-10">
        <div className="bg-white rounded-[32px] shadow-2xl p-10 border border-indigo-50">
          <div className="flex items-center space-x-4 mb-8">
            <div className="p-3 bg-indigo-600 rounded-2xl text-white shadow-lg shadow-indigo-100">
              <svg xmlns="http://www.w3.org/2000/svg" className="h-7 w-7" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M13 10V3L4 14h7v7l9-11h-7z" />
              </svg>
            </div>
            <div>
              <h2 className="text-3xl font-bold text-gray-900 tracking-tight">AI Personal Shopper</h2>
              <p className="text-gray-500 font-medium">LuminaAI understands your lifestyle.</p>
            </div>
          </div>
          <form onSubmit={handleAiSearch} className="space-y-6">
            <p className="text-gray-600 text-lg">Describe an activity, an occasion, or a problem, and we'll find the perfect match from our catalog.</p>
            <div className="flex flex-col sm:flex-row gap-3">
              <input 
                type="text"
                value={aiQuery}
                onChange={(e) => setAiQuery(e.target.value)}
                placeholder="e.g. I want to build a high-performance home office setup..."
                className="flex-1 px-6 py-4 rounded-[20px] border border-gray-100 bg-gray-50 focus:bg-white focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 outline-none transition-all text-gray-800 text-lg shadow-inner"
              />
              <button 
                type="submit"
                disabled={aiLoading}
                className="bg-gray-900 text-white px-10 py-4 rounded-[20px] font-bold hover:bg-gray-800 disabled:opacity-50 transition-all flex items-center justify-center space-x-2 shadow-lg active:scale-95"
              >
                {aiLoading ? (
                  <svg className="animate-spin h-5 w-5 text-white" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                ) : 'Get Suggestions'}
              </button>
            </div>
          </form>

          {suggestions.length > 0 && (
            <div className="mt-10 grid gap-4 animate-slide-up">
              {suggestions.map((s, idx) => (
                <div key={idx} className="flex flex-col sm:flex-row items-start sm:items-center p-6 bg-indigo-50/50 rounded-2xl border border-indigo-100 transition-all hover:shadow-md">
                  <div className="flex-1 mb-4 sm:mb-0">
                    <h4 className="font-bold text-indigo-900 text-lg">{s.productName}</h4>
                    <p className="text-indigo-700 leading-relaxed">{s.reason}</p>
                  </div>
                  <button 
                    onClick={() => {
                      const prod = products.find(p => p.name === s.productName);
                      if (prod) addToCart(prod);
                    }}
                    className="w-full sm:w-auto text-sm font-bold bg-white text-indigo-600 px-6 py-3 rounded-xl shadow-sm hover:shadow-md border border-indigo-100 transition-all active:scale-95 whitespace-nowrap"
                  >
                    Quick Add to Cart
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* Featured Products */}
      <section className="max-w-7xl mx-auto px-4">
        <div className="flex justify-between items-end mb-10">
          <div>
            <h2 className="text-4xl font-extrabold text-gray-900 tracking-tight">Curated Selection</h2>
            <p className="text-gray-500 text-lg font-medium mt-2">Hand-picked styles for your modern life.</p>
          </div>
          <a href="#/products" className="group flex items-center space-x-2 text-indigo-600 font-bold hover:text-indigo-700 transition-colors">
            <span>View All Products</span>
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 transition-transform group-hover:translate-x-1" viewBox="0 0 20 20" fill="currentColor">
              <path fillRule="evenodd" d="M10.293 3.293a1 1 0 011.414 0l6 6a1 1 0 010 1.414l-6 6a1 1 0 01-1.414-1.414L14.586 11H3a1 1 0 110-2h11.586l-4.293-4.293a1 1 0 010-1.414z" clipRule="evenodd" />
            </svg>
          </a>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {products.slice(0, 4).map((product, idx) => (
            <div key={product.id} className="group bg-white rounded-3xl overflow-hidden shadow-sm hover:shadow-2xl transition-all duration-500 border border-gray-100 animate-fade-in" style={{ animationDelay: `${idx * 100}ms` }}>
              <div className="relative aspect-[4/5] overflow-hidden">
                <img 
                  src={product.image} 
                  alt={product.name} 
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <button 
                  onClick={() => addToCart(product)}
                  className="absolute bottom-5 right-5 bg-white text-indigo-900 p-4 rounded-full shadow-xl opacity-0 translate-y-3 group-hover:opacity-100 group-hover:translate-y-0 transition-all duration-300 hover:bg-indigo-600 hover:text-white"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M12 4v16m8-8H4" />
                  </svg>
                </button>
              </div>
              <div className="p-8">
                <div className="flex justify-between items-start mb-3">
                  <h3 className="font-bold text-gray-900 text-xl leading-tight">
                    <a href={`#/product/${product.id}`} className="hover:text-indigo-600 transition-colors">{product.name}</a>
                  </h3>
                </div>
                <div className="flex items-center justify-between mt-4 pt-4 border-t border-gray-50">
                   <span className="font-extrabold text-indigo-600 text-2xl tracking-tighter">${product.price}</span>
                   <div className="flex items-center space-x-1">
                      <svg className="h-4 w-4 text-yellow-400" fill="currentColor" viewBox="0 0 20 20">
                        <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                      </svg>
                      <span className="text-sm font-bold text-gray-700">{product.rating}</span>
                   </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Brand Trust */}
      <section className="bg-gray-50 py-16">
        <div className="max-w-7xl mx-auto px-4 text-center">
          <p className="text-gray-400 font-bold uppercase tracking-widest text-xs mb-10">Trusted by modern consumers worldwide</p>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 opacity-40 grayscale hover:grayscale-0 transition-all">
             <div className="flex items-center justify-center font-black text-2xl">TECHFLOW</div>
             <div className="flex items-center justify-center font-black text-2xl">AURAWARE</div>
             <div className="flex items-center justify-center font-black text-2xl">PRISMIC</div>
             <div className="flex items-center justify-center font-black text-2xl">ECOGLOW</div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;
