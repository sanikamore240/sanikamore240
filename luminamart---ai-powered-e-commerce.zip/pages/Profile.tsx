
import React from 'react';
import { useApp } from '../context/AppContext';

const Profile: React.FC = () => {
  const { user, orders, loading } = useApp();

  if (!user) return <div className="p-20 text-center">Please log in to view your profile.</div>;

  return (
    <div className="max-w-4xl mx-auto px-4 py-12">
      <div className="bg-white rounded-3xl shadow-sm border border-gray-100 overflow-hidden mb-8">
        <div className="bg-indigo-600 h-32 relative">
          <div className="absolute -bottom-10 left-8">
            <div className="w-24 h-24 bg-white rounded-2xl shadow-lg border-4 border-white flex items-center justify-center text-3xl font-bold text-indigo-600">
              {user.name.charAt(0)}
            </div>
          </div>
        </div>
        <div className="pt-14 pb-8 px-8">
          <h1 className="text-3xl font-bold text-gray-900">{user.name}</h1>
          <p className="text-gray-500">{user.email}</p>
        </div>
      </div>

      <h2 className="text-2xl font-bold text-gray-900 mb-6">Order History</h2>
      
      {loading ? (
        <div className="text-center py-12 text-gray-400">Loading your orders...</div>
      ) : orders.length === 0 ? (
        <div className="bg-gray-50 rounded-2xl p-12 text-center border-2 border-dashed border-gray-200">
          <p className="text-gray-500">You haven't placed any orders yet.</p>
          <a href="#/" className="text-indigo-600 font-bold mt-4 inline-block">Start Shopping</a>
        </div>
      ) : (
        <div className="space-y-4">
          {orders.map(order => (
            <div key={order.id} className="bg-white p-6 rounded-2xl shadow-sm border border-gray-100">
              <div className="flex flex-col sm:flex-row justify-between mb-4 pb-4 border-b border-gray-50">
                <div>
                  <span className="text-xs font-bold text-indigo-600 uppercase tracking-wider">{order.id}</span>
                  <p className="text-sm text-gray-500">Placed on {new Date(order.createdAt).toLocaleDateString()}</p>
                </div>
                <div className="mt-2 sm:mt-0 text-right">
                  <span className="px-3 py-1 bg-blue-50 text-blue-600 rounded-full text-xs font-bold uppercase">
                    {order.status}
                  </span>
                  <p className="font-bold text-gray-900 text-lg mt-1">${order.total.toFixed(2)}</p>
                </div>
              </div>
              <div className="flex -space-x-2 overflow-hidden">
                {order.items.map((item, idx) => (
                  <img 
                    key={idx} 
                    src={item.image} 
                    alt={item.name} 
                    className="w-10 h-10 rounded-full border-2 border-white object-cover"
                    title={item.name}
                  />
                ))}
                {order.items.length > 5 && (
                  <div className="w-10 h-10 rounded-full border-2 border-white bg-gray-100 flex items-center justify-center text-xs font-bold text-gray-500">
                    +{order.items.length - 5}
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default Profile;
