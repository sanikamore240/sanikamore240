
import React, { useState } from 'react';
import { useApp } from '../context/AppContext';
import { AuthMode } from '../types';

const Auth: React.FC = () => {
  const { login, register } = useApp();
  const [mode, setMode] = useState<AuthMode>(AuthMode.LOGIN);
  const [formData, setFormData] = useState({
    email: '',
    name: '',
    phone: '',
    address: '',
    password: ''
  });
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);
    try {
      if (mode === AuthMode.LOGIN) {
        await login(formData.email);
      } else {
        await register({
          name: formData.name,
          email: formData.email,
          phone: formData.phone,
          address: formData.address
        });
      }
      window.location.hash = '/';
    } catch (err: any) {
      setError(err.message || 'Authentication failed');
    } finally {
      setIsLoading(false);
    }
  };

  const toggleMode = () => {
    setMode(prev => prev === AuthMode.LOGIN ? AuthMode.REGISTER : AuthMode.LOGIN);
    setError('');
  };

  return (
    <div className="max-w-xl mx-auto px-4 py-16">
      <div className="bg-white p-8 md:p-12 rounded-[40px] shadow-2xl border border-gray-100 animate-slide-up">
        <div className="text-center mb-10">
          <div className="inline-flex p-4 bg-indigo-50 rounded-3xl text-indigo-600 mb-6">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 00-2 2zm10-10V7a4 4 0 00-8 0v4h8z" />
            </svg>
          </div>
          <h1 className="text-4xl font-extrabold text-gray-900 mb-3 tracking-tight">
            {mode === AuthMode.LOGIN ? 'Welcome Back' : 'Create Account'}
          </h1>
          <p className="text-gray-500 font-medium">
            {mode === AuthMode.LOGIN 
              ? 'Please enter your login details to continue' 
              : 'Enter your profile details to join LuminaMart'}
          </p>
        </div>

        {error && (
          <div className="mb-8 p-4 bg-red-50 text-red-600 rounded-2xl text-sm font-bold border border-red-100 flex items-center space-x-3">
            <svg className="h-5 w-5" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
            </svg>
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-5">
          {mode === AuthMode.REGISTER && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5 animate-fade-in">
              <div className="space-y-2">
                <label className="text-xs font-bold text-gray-400 uppercase tracking-widest ml-1">Full Name</label>
                <input 
                  type="text" 
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  className="w-full p-4 border border-gray-100 bg-gray-50 rounded-2xl focus:bg-white focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 outline-none transition-all" 
                  placeholder="Jane Doe"
                  required
                />
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold text-gray-400 uppercase tracking-widest ml-1">Phone Number</label>
                <input 
                  type="tel" 
                  value={formData.phone}
                  onChange={(e) => setFormData({...formData, phone: e.target.value})}
                  className="w-full p-4 border border-gray-100 bg-gray-50 rounded-2xl focus:bg-white focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 outline-none transition-all" 
                  placeholder="+1 (555) 000-0000"
                  required
                />
              </div>
              <div className="space-y-2 sm:col-span-2">
                <label className="text-xs font-bold text-gray-400 uppercase tracking-widest ml-1">Shipping Address</label>
                <input 
                  type="text" 
                  value={formData.address}
                  onChange={(e) => setFormData({...formData, address: e.target.value})}
                  className="w-full p-4 border border-gray-100 bg-gray-50 rounded-2xl focus:bg-white focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 outline-none transition-all" 
                  placeholder="123 Luxury Ave, Silicon Valley, CA"
                  required
                />
              </div>
            </div>
          )}

          <div className="space-y-2">
            <label className="text-xs font-bold text-gray-400 uppercase tracking-widest ml-1">Email Address</label>
            <input 
              type="email" 
              value={formData.email}
              onChange={(e) => setFormData({...formData, email: e.target.value})}
              className="w-full p-4 border border-gray-100 bg-gray-50 rounded-2xl focus:bg-white focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 outline-none transition-all" 
              placeholder="jane@example.com"
              required
            />
          </div>

          <div className="space-y-2">
            <label className="text-xs font-bold text-gray-400 uppercase tracking-widest ml-1">Secure Password</label>
            <input 
              type="password" 
              value={formData.password}
              onChange={(e) => setFormData({...formData, password: e.target.value})}
              className="w-full p-4 border border-gray-100 bg-gray-50 rounded-2xl focus:bg-white focus:ring-4 focus:ring-indigo-500/10 focus:border-indigo-500 outline-none transition-all" 
              placeholder="••••••••"
              required
            />
          </div>

          <div className="pt-4">
            <button 
              type="submit"
              disabled={isLoading}
              className="w-full bg-indigo-600 text-white py-5 rounded-2xl font-bold text-lg hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-100 disabled:opacity-50 active:scale-[0.98] flex items-center justify-center space-x-2"
            >
              {isLoading ? (
                <svg className="animate-spin h-5 w-5 text-white" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
              ) : (
                <span>{mode === AuthMode.LOGIN ? 'Sign In' : 'Complete Registration'}</span>
              )}
            </button>
          </div>
        </form>

        <div className="mt-10 text-center">
          <button 
            onClick={toggleMode}
            className="text-sm font-bold text-indigo-600 hover:text-indigo-800 transition-colors group"
          >
            {mode === AuthMode.LOGIN ? (
              <span>New here? <span className="underline decoration-indigo-200 group-hover:decoration-indigo-600">Create an account</span></span>
            ) : (
              <span>Already have an account? <span className="underline decoration-indigo-200 group-hover:decoration-indigo-600">Sign in instead</span></span>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};

export default Auth;
