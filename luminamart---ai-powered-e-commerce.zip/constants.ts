
import { Product } from './types';

export const INITIAL_PRODUCTS: Product[] = [
  {
    id: '1',
    name: 'Aura Wireless Headphones',
    description: 'Noise-canceling over-ear headphones with 40-hour battery life and premium sound quality.',
    price: 299.99,
    category: 'Audio',
    image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=800&q=80',
    rating: 4.8,
    stock: 15
  },
  {
    id: '2',
    name: 'Nebula Smart Watch',
    description: 'Track your fitness, notifications, and health metrics with our sleekest smartwatch yet.',
    price: 199.99,
    category: 'Wearables',
    image: 'https://images.unsplash.com/photo-1523275335684-37898b6baf30?auto=format&fit=crop&w=800&q=80',
    rating: 4.5,
    stock: 22
  },
  {
    id: '3',
    name: 'Zenith Camera Lens',
    description: 'Capture every detail with this professional-grade 50mm f/1.8 prime lens.',
    price: 449.00,
    category: 'Photography',
    image: 'https://images.unsplash.com/photo-1516035069371-29a1b244cc32?auto=format&fit=crop&w=800&q=80',
    rating: 4.9,
    stock: 8
  },
  {
    id: '4',
    name: 'EcoLite Desk Lamp',
    description: 'Sustainable bamboo LED lamp with adjustable brightness and warm light settings.',
    price: 59.99,
    category: 'Home',
    image: 'https://images.unsplash.com/photo-1534073828943-f801091bb18c?auto=format&fit=crop&w=800&q=80',
    rating: 4.2,
    stock: 40
  },
  {
    id: '5',
    name: 'Titan Gaming Mouse',
    description: 'Ultra-responsive 16,000 DPI gaming mouse with customizable RGB lighting.',
    price: 79.99,
    category: 'Gaming',
    image: 'https://images.unsplash.com/photo-1527443224154-c4a3942d3acf?auto=format&fit=crop&w=800&q=80',
    rating: 4.7,
    stock: 30
  },
  {
    id: '6',
    name: 'Nova Backpack',
    description: 'Water-resistant, anti-theft laptop backpack designed for the modern commuter.',
    price: 89.00,
    category: 'Accessories',
    image: 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=800&q=80',
    rating: 4.4,
    stock: 25
  },
  {
    id: '7',
    name: 'Lumina Mechanical Keyboard',
    description: 'Tactile switches with low latency and stunning per-key RGB backlighting.',
    price: 149.99,
    category: 'Gaming',
    image: 'https://images.unsplash.com/photo-1511467687858-23d96c32e4ae?auto=format&fit=crop&w=800&q=80',
    rating: 4.6,
    stock: 12
  },
  {
    id: '8',
    name: 'Prism 4K Monitor',
    description: '27-inch Ultra HD display with HDR support and color-accurate IPS panel.',
    price: 599.00,
    category: 'Computing',
    image: 'https://images.unsplash.com/photo-1527443224154-c4a3942d3acf?auto=format&fit=crop&w=800&q=80',
    rating: 4.9,
    stock: 5
  },
  {
    id: '9',
    name: 'Sonic Soundbar',
    description: 'Immersive Dolby Atmos soundbar with wireless subwoofer for your home theater.',
    price: 349.50,
    category: 'Audio',
    image: 'https://images.unsplash.com/photo-1545454675-3531b543be5d?auto=format&fit=crop&w=800&q=80',
    rating: 4.3,
    stock: 18
  },
  {
    id: '10',
    name: 'Vector Drone',
    description: 'Compact 4K foldable drone with GPS return-to-home and 30-minute flight time.',
    price: 799.00,
    category: 'Photography',
    image: 'https://images.unsplash.com/photo-1473968512647-3e44a224fe8f?auto=format&fit=crop&w=800&q=80',
    rating: 4.8,
    stock: 6
  },
  {
    id: '11',
    name: 'Minimalist Walnut Desk',
    description: 'Solid walnut wood desk with built-in cable management and sleek metal legs.',
    price: 899.00,
    category: 'Home',
    image: 'https://images.unsplash.com/photo-1518455027359-f3f8164ba6bd?auto=format&fit=crop&w=800&q=80',
    rating: 4.7,
    stock: 3
  },
  {
    id: '12',
    name: 'Orbit Smart Home Hub',
    description: 'Control your entire home with voice commands and an intuitive touchscreen display.',
    price: 129.00,
    category: 'Home',
    image: 'https://images.unsplash.com/photo-1558002038-1055907df827?auto=format&fit=crop&w=800&q=80',
    rating: 4.1,
    stock: 25
  }
];
