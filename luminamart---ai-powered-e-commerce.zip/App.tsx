
import React, { useState, useEffect } from 'react';
import { AppProvider } from './context/AppContext';
import Navbar from './components/Navbar';
import CartDrawer from './components/CartDrawer';
import Home from './pages/Home';
import Products from './pages/Products';
import ProductDetail from './pages/ProductDetail';
import Cart from './pages/Cart';
import Checkout from './pages/Checkout';
import Auth from './pages/Auth';
import Profile from './pages/Profile';
import Admin from './pages/Admin';

const App: React.FC = () => {
  const [route, setRoute] = useState(window.location.hash || '#/');

  useEffect(() => {
    const handleHashChange = () => setRoute(window.location.hash || '#/');
    window.addEventListener('hashchange', handleHashChange);
    return () => window.removeEventListener('hashchange', handleHashChange);
  }, []);

  const renderRoute = () => {
    const path = route.replace('#', '');
    if (path === '/' || path === '') return <Home />;
    if (path === '/products') return <Products />;
    if (path === '/cart') return <Cart />;
    if (path === '/checkout') return <Checkout />;
    if (path === '/auth') return <Auth />;
    if (path === '/profile') return <Profile />;
    if (path === '/admin') return <Admin />;
    
    const productMatch = path.match(/\/product\/(.+)/);
    if (productMatch) return <ProductDetail productId={productMatch[1]} />;

    return <div className="p-20 text-center text-gray-400">Page not found</div>;
  };

  return (
    <AppProvider>
      <div className="min-h-screen flex flex-col bg-[#fcfcfd]">
        <Navbar />
        <CartDrawer />
        <main className="flex-grow">
          {renderRoute()}
        </main>
        <footer className="bg-gray-900 text-gray-400 py-12 px-4">
          <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-4 gap-12">
            <div>
              <h4 className="text-white font-bold text-xl mb-6">LuminaMart</h4>
              <p className="text-sm leading-relaxed">Redefining the digital marketplace with curated quality and intelligent shopping experiences.</p>
            </div>
            <div>
              <h5 className="text-white font-bold mb-4">Shop</h5>
              <ul className="space-y-2 text-sm">
                <li><a href="#/products" className="hover:text-indigo-400">All Products</a></li>
                <li><a href="#/" className="hover:text-indigo-400">Featured</a></li>
                <li><a href="#/" className="hover:text-indigo-400">New Arrivals</a></li>
              </ul>
            </div>
            <div>
              <h5 className="text-white font-bold mb-4">Support</h5>
              <ul className="space-y-2 text-sm">
                <li><a href="#/" className="hover:text-indigo-400">FAQ</a></li>
                <li><a href="#/" className="hover:text-indigo-400">Shipping</a></li>
                <li><a href="#/" className="hover:text-indigo-400">Returns</a></li>
              </ul>
            </div>
            <div>
              <h5 className="text-white font-bold mb-4">Newsletter</h5>
              <div className="flex bg-gray-800 rounded-lg p-1">
                <input type="email" placeholder="Email" className="bg-transparent border-none outline-none px-3 py-2 text-xs w-full" />
                <button className="bg-indigo-600 text-white px-4 py-2 rounded-md text-xs font-bold hover:bg-indigo-700">Join</button>
              </div>
            </div>
          </div>
          <div className="max-w-7xl mx-auto border-t border-gray-800 mt-12 pt-8 text-center text-xs">
            © 2024 LuminaMart AI. All rights reserved.
          </div>
        </footer>
      </div>
    </AppProvider>
  );
};

export default App;
