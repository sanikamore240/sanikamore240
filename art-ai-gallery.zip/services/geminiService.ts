
import { GoogleGenAI, Type } from "@google/genai";
import { AIInsight } from "../types";

export const getAIInsight = async (imageUrl: string): Promise<AIInsight> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  try {
    // Fetch the image and convert to base64
    const responseImage = await fetch(imageUrl);
    const blob = await responseImage.blob();
    const base64Data = await new Promise<string>((resolve) => {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = (reader.result as string).split(',')[1];
        resolve(base64String);
      };
      reader.readAsDataURL(blob);
    });

    const result = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: {
        parts: [
          {
            inlineData: {
              data: base64Data,
              mimeType: blob.type || 'image/jpeg'
            }
          },
          {
            text: "Analyze this image. Provide a creative artistic analysis, three suggested tags, and describe the 'vibe' in one sentence. Return as JSON."
          }
        ]
      },
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            analysis: { type: Type.STRING },
            suggestedTags: { 
              type: Type.ARRAY, 
              items: { type: Type.STRING } 
            },
            vibe: { type: Type.STRING }
          },
          required: ["analysis", "suggestedTags", "vibe"]
        },
        thinkingConfig: { thinkingBudget: 0 }
      }
    });

    return JSON.parse(result.text || '{}') as AIInsight;
  } catch (error) {
    console.error("Gemini Insight Error:", error);
    return {
      analysis: "Could not perform AI analysis at this time. The beauty of this piece speaks for itself.",
      suggestedTags: ["Art", "Inspiration", "Visuals"],
      vibe: "A mystery wrapped in an enigma."
    };
  }
};
