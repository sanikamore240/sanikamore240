
import React from 'react';
import { Category } from '../types';
import { CATEGORIES } from '../constants';

interface FilterBarProps {
  activeCategory: Category;
  onSelectCategory: (category: Category) => void;
}

const FilterBar: React.FC<FilterBarProps> = ({ activeCategory, onSelectCategory }) => {
  return (
    <div className="flex flex-wrap justify-center gap-2 py-8 px-4">
      {CATEGORIES.map((category) => (
        <button
          key={category}
          onClick={() => onSelectCategory(category)}
          className={`px-5 py-2 rounded-full text-sm font-medium transition-all duration-300 border ${
            activeCategory === category
              ? 'bg-blue-600 border-blue-500 text-white shadow-lg shadow-blue-900/40'
              : 'bg-slate-800/50 border-slate-700 text-slate-400 hover:border-slate-500 hover:text-white hover:bg-slate-800'
          }`}
        >
          {category}
        </button>
      ))}
    </div>
  );
};

export default FilterBar;
