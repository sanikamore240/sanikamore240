
import React, { useState, useEffect, useCallback } from 'react';
import { GalleryImage, AIInsight } from '../types';
import { X, ChevronLeft, ChevronRight, Sparkles, Download } from './Icons';
import { getAIInsight } from '../services/geminiService';

interface LightboxProps {
  image: GalleryImage;
  onClose: () => void;
  onPrev: () => void;
  onNext: () => void;
}

const Lightbox: React.FC<LightboxProps> = ({ image, onClose, onPrev, onNext }) => {
  const [insight, setInsight] = useState<AIInsight | null>(null);
  const [loadingInsight, setLoadingInsight] = useState(false);
  const [activeTab, setActiveTab] = useState<'info' | 'ai'>('info');

  const fetchInsight = useCallback(async () => {
    setLoadingInsight(true);
    setInsight(null);
    const data = await getAIInsight(image.url);
    setInsight(data);
    setLoadingInsight(false);
  }, [image.url]);

  useEffect(() => {
    setInsight(null);
    setActiveTab('info');
    // We don't auto-fetch AI to save tokens/latency unless the user clicks
  }, [image.id]);

  useEffect(() => {
    const handleKeydown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowLeft') onPrev();
      if (e.key === 'ArrowRight') onNext();
    };
    window.addEventListener('keydown', handleKeydown);
    return () => window.removeEventListener('keydown', handleKeydown);
  }, [onClose, onPrev, onNext]);

  return (
    <div className="fixed inset-0 z-50 flex flex-col md:flex-row bg-slate-950/95 backdrop-blur-xl animate-in fade-in duration-300">
      {/* Media Side */}
      <div className="relative flex-1 flex items-center justify-center p-4 overflow-hidden">
        <button
          onClick={onClose}
          className="absolute top-6 left-6 z-10 p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors md:hidden"
        >
          <X className="w-6 h-6" />
        </button>

        <button
          onClick={onPrev}
          className="absolute left-4 top-1/2 -translate-y-1/2 p-3 rounded-full bg-white/5 hover:bg-white/10 text-white transition-all hover:scale-110"
        >
          <ChevronLeft className="w-8 h-8" />
        </button>

        <img
          src={image.url}
          alt={image.title}
          className="max-w-full max-h-[80vh] object-contain rounded-lg shadow-2xl animate-in zoom-in-95 duration-500"
        />

        <button
          onClick={onNext}
          className="absolute right-4 top-1/2 -translate-y-1/2 p-3 rounded-full bg-white/5 hover:bg-white/10 text-white transition-all hover:scale-110"
        >
          <ChevronRight className="w-8 h-8" />
        </button>
      </div>

      {/* Sidebar Info */}
      <div className="w-full md:w-[400px] h-full bg-slate-900 border-l border-slate-800 flex flex-col">
        <div className="hidden md:flex justify-between items-center p-6 border-b border-slate-800">
          <h2 className="text-xl font-bold">Details</h2>
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-slate-800 text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex border-b border-slate-800">
          <button
            onClick={() => setActiveTab('info')}
            className={`flex-1 py-4 text-sm font-semibold transition-colors ${
              activeTab === 'info' ? 'text-blue-400 border-b-2 border-blue-400' : 'text-slate-500 hover:text-slate-300'
            }`}
          >
            INFORMATION
          </button>
          <button
            onClick={() => setActiveTab('ai')}
            className={`flex-1 py-4 text-sm font-semibold flex items-center justify-center gap-2 transition-colors ${
              activeTab === 'ai' ? 'text-purple-400 border-b-2 border-purple-400' : 'text-slate-500 hover:text-slate-300'
            }`}
          >
            <Sparkles className="w-4 h-4" />
            AI INSIGHTS
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-6">
          {activeTab === 'info' ? (
            <div className="space-y-6 animate-in slide-in-from-right-4 duration-300">
              <div>
                <span className="text-xs font-bold uppercase tracking-widest text-blue-500">
                  {image.category}
                </span>
                <h1 className="text-2xl font-bold mt-1 text-white">{image.title}</h1>
                <p className="text-slate-400 mt-2 italic">by {image.author}</p>
              </div>

              <div>
                <h4 className="text-sm font-bold text-slate-300 uppercase tracking-wider mb-2">About</h4>
                <p className="text-slate-300 leading-relaxed">{image.description}</p>
              </div>

              <div className="pt-6 border-t border-slate-800">
                <button 
                  onClick={() => window.open(image.url, '_blank')}
                  className="w-full py-3 bg-slate-800 hover:bg-slate-700 text-white rounded-xl flex items-center justify-center gap-2 font-medium transition-colors"
                >
                  <Download className="w-5 h-5" />
                  Download High-Res
                </button>
              </div>
            </div>
          ) : (
            <div className="space-y-6 animate-in slide-in-from-right-4 duration-300">
              {!insight && !loadingInsight && (
                <div className="flex flex-col items-center justify-center py-12 text-center">
                  <div className="w-16 h-16 bg-purple-500/10 rounded-full flex items-center justify-center mb-4">
                    <Sparkles className="w-8 h-8 text-purple-400" />
                  </div>
                  <h3 className="text-lg font-bold text-white mb-2">Unlock AI Perspective</h3>
                  <p className="text-slate-400 text-sm mb-6">
                    Let Gemini analyze the composition, mood, and deeper meaning of this image.
                  </p>
                  <button
                    onClick={fetchInsight}
                    className="px-6 py-2 bg-purple-600 hover:bg-purple-500 text-white rounded-lg font-medium transition-all shadow-lg shadow-purple-900/30"
                  >
                    Analyze Image
                  </button>
                </div>
              )}

              {loadingInsight && (
                <div className="flex flex-col items-center justify-center py-12 space-y-4">
                  <div className="w-10 h-10 border-4 border-purple-500 border-t-transparent rounded-full animate-spin"></div>
                  <p className="text-purple-300 font-medium animate-pulse">Consulting the AI...</p>
                </div>
              )}

              {insight && (
                <div className="space-y-6 animate-in fade-in duration-500">
                  <div>
                    <h4 className="text-sm font-bold text-purple-400 uppercase tracking-wider mb-2">Artistic Analysis</h4>
                    <p className="text-slate-300 leading-relaxed text-sm">
                      {insight.analysis}
                    </p>
                  </div>

                  <div>
                    <h4 className="text-sm font-bold text-purple-400 uppercase tracking-wider mb-2">Atmosphere</h4>
                    <div className="p-3 bg-purple-500/10 border border-purple-500/20 rounded-lg text-purple-200 text-sm italic">
                      "{insight.vibe}"
                    </div>
                  </div>

                  <div>
                    <h4 className="text-sm font-bold text-purple-400 uppercase tracking-wider mb-2">Suggested Tags</h4>
                    <div className="flex flex-wrap gap-2">
                      {insight.suggestedTags.map(tag => (
                        <span key={tag} className="px-3 py-1 bg-slate-800 rounded-md text-xs text-slate-300 border border-slate-700">
                          #{tag.toLowerCase().replace(/\s/g, '')}
                        </span>
                      ))}
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Lightbox;
