
import React from 'react';
import { GalleryImage } from '../types';

interface GalleryGridProps {
  images: GalleryImage[];
  onImageClick: (image: GalleryImage) => void;
}

const GalleryGrid: React.FC<GalleryGridProps> = ({ images, onImageClick }) => {
  if (images.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center py-20 text-slate-500">
        <p className="text-xl">No images found in this category.</p>
      </div>
    );
  }

  return (
    <div className="masonry-grid px-4 pb-12 animate-in fade-in duration-700">
      {images.map((image) => (
        <div
          key={image.id}
          className="masonry-item group relative overflow-hidden rounded-xl bg-slate-800/30 cursor-pointer border border-slate-800/50 hover:border-slate-600 transition-all duration-500"
          onClick={() => onImageClick(image)}
        >
          <img
            src={image.url}
            alt={image.title}
            loading="lazy"
            className="w-full h-auto object-cover transform transition-transform duration-700 group-hover:scale-105"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-6">
            <span className="text-xs font-bold uppercase tracking-widest text-blue-400 mb-1">
              {image.category}
            </span>
            <h3 className="text-lg font-bold text-white line-clamp-1">
              {image.title}
            </h3>
            <p className="text-sm text-slate-300 line-clamp-2 mt-1">
              {image.description}
            </p>
          </div>
        </div>
      ))}
    </div>
  );
};

export default GalleryGrid;
